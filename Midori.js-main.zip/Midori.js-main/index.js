const { Plugins } = require ("./src/index.js")


console.log('\033[36mmidori.js is trying to be packed!');


console.log('\033[92mDiscord server : https://discord.gg/xPURT2B3sA'); setTimeout(() => { 
  
console.log('\033[32mmidori.js is now sucessfully packed!'); }, 1500);


module.exports = {
  Plugins
};
